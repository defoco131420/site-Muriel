=== EmallShop ===
Contributors: the Presslayouts team
Tags: green, blue, red, orange, two-columns, left-sidebar, fixed-layout, responsive-layout, accessibility-ready, custom-colors, custom-menu, featured-images, microformats, post-formats, rtl-language-support, sticky-post, threaded-comments, translation-ready
Requires at least: 4.4.2
Tested up to: 4.4.2
Stable tag: 4.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
EmallShop is a clean, modern, user friendly, responsive and highly customizable Wordpress Theme, built for especially for your WooCommerce electronics store.

== Documentation ==
You can view the detailed EmallShop latest documentation at http://docs.presslayouts.com/emallshop/
