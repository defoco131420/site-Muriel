<?php
if(emallshop_get_option('show-topbar', 1)==1):?>
<div class="header-topbar">
	<div class="container">
		<div class="row">
			<div class="col-sm-6 col-md-4 text-left">
				<?php if( function_exists( 'emallshop_customer_support' ) ) {
					emallshop_customer_support();
				}?>
			</div>
			<div class="col-sm-6 col-md-8 text-right">
				<div class="topbar-right">
					
					<a href="http://201.63.160.58:9001/cgi-bin/jtvdvend.exe?idd=jotec&dir=MATRIZ&C001=00001&C002=MURIELC&C999=LOGIN" target="_blank"><i class="fa fa-user-circle-o" aria-hidden="true"></i>Pedido</a>
					|
					<a href="http://201.63.160.58:9001/cgi-bin/jtgeseus.exe" target="_blank"><i class="fa fa-user-circle-o" aria-hidden="true"></i>Interno</a>
					|
					<div class="btn-group" role="group">
						<button type="button" class="btn-login" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
							WebMail
							<span class="caret"></span>
						</button>

						<ul class="dropdown-menu">


							<!--Start header-middle-top -->
							<div class="header-middle-top">
								<form name="form" action="https://webmail-seguro.com.br/muriel.com.br/" method="post" class="formwebmail"> 
									<input name="_action" value="login" type="hidden"> 
									<div class="user_webmail">
										<label for="rcmloginuser">Usuário</label>
										<input name="_domain" value="muriel.com.br" type="hidden" >
										<input name="_user" id="rcmloginuser" class="large" type="text" placeholder="seuemail@muriel.com.br"> <!--b>@muriel.com.br</b-->
									</div> 
									<div class="senha_webmail">
										<label for="rcmloginpwd">Senha</label>
										<input name="_pass" id="rcmloginpwd" class="large" type="password">

										<p class="login-remember"><label><input name="rememberme" id="rememberme" value="forever" type="checkbox"> Lembrar-me</label></p>

										<input class="formcolor" value="Ok" type="submit">
									</div> 

								</form>
								<a class="esqueci" href="http://www.muriel.com.br/wp-login.php?action=lostpassword">Esqueci a senha</a>
							</div>

						</div>
					</ul>	
					<!--Start header-middle-top -->





					<?php
					if( function_exists( 'emallshop_welcome_message' ) ) {
						emallshop_welcome_message();
					}
					if( function_exists( 'emallshop_dokan_header_user_menu' ) ) {
						emallshop_dokan_header_user_menu();
					}else{					
						if( function_exists( 'emallshop_myaccount' ) ) {
							emallshop_myaccount();
						}

						if( function_exists( 'emallshop_checkout' ) ) {
							emallshop_checkout();
						}
					}
					if( function_exists( 'emallshop_currency' ) ) {
						emallshop_currency();
					}
					if( function_exists( 'emallshop_language' ) ) {
						emallshop_language();
					}?>                            
				</div>
			</div>
		</div>
	</div>
</div>
<?php endif;?>
<div class="header-middle">
	<div class="container">
		<div class="row">
			<div class="col-sm-3">
				<?php if( function_exists( 'emallshop_header_logo' ) ) {
					emallshop_header_logo();
				}?>
			</div>
			<div class="col-sm-6">
				<?php if( function_exists( 'emallshop_products_live_search_form' ) ) {
					emallshop_products_live_search_form();
				}?>
			</div>                    
			<div class="col-sm-3">
				<div class="header-right">
					<?php if( function_exists( 'emallshop_wishlist' ) ) {
						emallshop_wishlist();
					}
					if( function_exists( 'emallshop_campare' ) ) {
						emallshop_campare();
					}
					if( function_exists( 'emallshop_header_cart' ) ) {
						emallshop_header_cart();
					}?>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="header-navigation">
	<div class="container">
		<div class="row">
			<!--div class="col-xs-6 col-sm-5 col-md-3">
				<?php if( function_exists( 'emallshop_category_menu' ) ) {
					emallshop_category_menu();
				}?>
			</div-->
			<div class="col-md-12">
				<div class="menu-center">
					<?php if( function_exists( 'emallshop_header_menu' ) ) {
						emallshop_header_menu();
					}?>				
				</div>
			</div>			
		</div>
	</div>
</div>